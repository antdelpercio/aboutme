<p>id="demo" onclick="myFunction()">Click this to see my favorite color</p>

<script>
function myFunction() {
  document.getElementById("demo").style.color = "red";
}
/*Clicking the button changes the text to my favorite color*/